# Red‑Blue Pill — Flip Your Algorithm

> **Burst your bubble.** See what your feed hides. Red‑Blue Pill lets you toggle to an *opposite* or *diversified* view on major sites—starting with YouTube and Google Search—while keeping your data on your device.

## ✨ What it does (MVP)

* **Profile readback (local):** On‑device heuristics infer what your feed favors (topics, brands, leanings).
* **Flip mode:** Overlay clearly labeled panels that surface **contrasting content** (e.g., opposite political slant, competitor brands, more uplifting items).
* **YouTube:** Adds an “Opposite topics” panel that links to search terms representing the opposing perspective.
* **Google Search:** Displays an “Outside your bubble” panel linking to alternate search engines for the same query.
* **Controls:** Global ON/OFF toggle, intensity slider, per‑category switches (future), and **Delete my data**.

The extension **adds** labeled overlays; it doesn’t impersonate accounts or secretly replace native content.

## 🛡️ Privacy & Data

* **Default: on‑device only.** Analysis and settings live in your browser (`chrome.storage.local`).
* **Opt‑in telemetry (optional):** If enabled, only high‑level, **anonymous** usage stats are sent to improve suggestions. Off by default.
* **One‑click wipe:** A visible “Delete my data” button clears everything the extension stored.
* **No third‑party sharing:** We do not sell or share personal data. Anonymized aggregate metrics are used only if you opt in.

## 🧭 Why this exists

Algorithms narrow what we see. Over time, feeds reflect our preferences back at us, making other viewpoints (or even other *products*) seem invisible. Red‑Blue Pill gives you a **frictionless switch** to explore outside that bubble—on your terms.

## 🧩 Scope & Roadmap

**Current (MVP):**

* Chromium browsers (Chrome/Edge/Brave)
* Sites: **YouTube** + **Google Search**
* Local heuristics; basic “opposite” rules

**Next:**

* Smarter opposite mappings (media‑bias sources, brand competitor graph, mood safeguards)
* Side‑by‑side “neutral” result diffs for Google
* Per‑site toggles & better small‑screen layouts

**Later (exploration):**

* Facebook/Instagram analysis overlays (non‑intrusive; avoid brittle injections)
* Firefox (desktop + Android) & Safari Web Extension packaging
* Classroom/education mode (media‑literacy exercises)

## 🛠️ Local install (for testers)

1. Clone or download this repo.
2. In Chrome/Edge: open `chrome://extensions` (or `edge://extensions`) → **Developer mode** ON.
3. Click **Load unpacked** → select the project folder.
4. Pin the extension icon → visit **YouTube** or **Google** to see overlays.
5. Use the popup to toggle features; try **Options → Delete my data**.

## 📦 Publishing (when ready)

* **Chrome Web Store / Edge Add‑ons:** Zip the folder, upload, and complete listing (screenshots, concise description, clear privacy policy, minimal permissions).
* **Firefox AMO:** Submit as a WebExtension (desktop; can later target Android).
* **Safari (iOS/macOS):** Wrap via Xcode’s “Safari Web Extension” for App Store distribution.

Keep permissions narrow (host‑specific), use Manifest V3, and explain privacy in plain language to pass review smoothly.

## 🤝 Contributing

We welcome suggestions and careful PRs—especially around:

* Opposite‑content mapping (brands, politics, mood)
* Safe/reputable source lists
* UX polish and accessibility

**Guidelines**

* Keep all processing local unless explicitly marked optional/telemetry.
* Label overlays clearly; don’t break native site UX.
* No scraping that mimics logins or evades rate limits.
* Be kind. Respect different viewpoints.

## 📄 License

This project is licensed under the MIT License. See the [LICENSE](LICENSE) file for details.
